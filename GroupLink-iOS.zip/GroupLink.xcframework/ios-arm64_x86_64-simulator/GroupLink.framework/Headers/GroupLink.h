//
//  GroupLink.h
//  GroupLink
//
//  Created by Vitor Hugo on 21/08/23.
//

#import <Foundation/Foundation.h>

//! Project version number for GroupLink.
FOUNDATION_EXPORT double GroupLinkVersionNumber;

//! Project version string for GroupLink.
FOUNDATION_EXPORT const unsigned char GroupLinkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GroupLink/PublicHeader.h>


